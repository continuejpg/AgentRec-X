﻿import json
from pathlib import Path
d=json.loads(Path('runs/p8_d/current_intent/retrieval_eval.json').read_text(encoding='utf-8'))
print(json.dumps(d['aggregate'],ensure_ascii=False,indent=1))
# verify extended cases no test target and no holdout
from hashlib import sha256
cases=[json.loads(l) for l in Path('runs/p8_d/multiuser/cases.jsonl').read_text(encoding='utf-8').splitlines() if l.strip()]
hold=[c for c in cases if int(sha256(c['user_id'].encode()).hexdigest(),16)%5==0]
bad=[c for c in cases if c['target'] in c['history']]
print('cases',len(cases),'holdout_selected',len(hold),'target_in_history',len(bad))
print('keys',list(cases[0].keys()))
# policy results counts
res=[json.loads(l) for l in Path('runs/p8_d/multiuser/policy_results.jsonl').read_text(encoding='utf-8').splitlines() if l.strip()]
print('policy result keys',list(res[0].keys()))
print('candidate cache lines',sum(1 for _ in Path('runs/p8_d/multiuser/candidate_cache.jsonl').open(encoding='utf-8')))
