﻿import json
from pathlib import Path
rows=[json.loads(l) for l in Path('runs/p6_classical_eval/dev_20261107_125847/per_case.jsonl').read_text(encoding='utf-8').splitlines() if l.strip()]
print('rows',len(rows)); print(rows[0].keys()); print(json.dumps(rows[0],ensure_ascii=False)[:2000])
